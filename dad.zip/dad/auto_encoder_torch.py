import torch
import torch.nn as nn
import numpy as np
from sklearn.utils.validation import check_array, check_is_fitted
from sklearn.metrics import pairwise_distances


# inner_autoencoder 模块（作者自定义，封装模型结构）
class inner_autoencoder(nn.Module):
    def __init__(self, input_dim=50, encoding_dim=32):
        super(inner_autoencoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, encoding_dim),
            nn.ReLU()
        )
        self.decoder = nn.Sequential(
            nn.Linear(encoding_dim, 64),
            nn.ReLU(),
            nn.Linear(64, input_dim)
        )

    def forward(self, x):
        x = self.encoder(x)
        x = self.decoder(x)
        return x


# AutoEncoder 类
class AutoEncoder:
    def __init__(self, input_dim=50, encoding_dim=32, lr=1e-3, epochs=30, batch_size=32, verbose=True):
        self.input_dim = input_dim
        self.encoding_dim = encoding_dim
        self.lr = lr
        self.epochs = epochs
        self.batch_size = batch_size
        self.verbose = verbose
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = inner_autoencoder(input_dim=input_dim, encoding_dim=encoding_dim).to(self.device)

    def fit(self, X):
        X = check_array(X)
        self.model.train()
        dataset = torch.utils.data.TensorDataset(torch.tensor(X, dtype=torch.float32))
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=self.batch_size, shuffle=True)

        criterion = nn.MSELoss()
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)

        for epoch in range(self.epochs):
            epoch_loss = 0.0
            for batch in dataloader:
                x_batch = batch[0].to(self.device)
                optimizer.zero_grad()
                output = self.model(x_batch)
                loss = criterion(output, x_batch)
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item()
            if self.verbose:
                print(f"Epoch [{epoch+1}/{self.epochs}], Loss: {epoch_loss:.4f}")
        return self

    def decision_function(self, X):
        check_is_fitted(self, ['model'])
        X = check_array(X)
        self.model.eval()
        with torch.no_grad():
            inputs = torch.tensor(X, dtype=torch.float32).to(self.device)
            outputs = self.model(inputs)
            loss = nn.functional.mse_loss(outputs, inputs, reduction='none')
            return loss.mean(dim=1).cpu().numpy()

    def predict(self, X, threshold=None):
        scores = self.decision_function(X)
        if threshold is None:
            threshold = np.percentile(scores, 95)
        return (scores > threshold).astype(int)


# pairwise_distances_no_broadcast（从 pyod 源码中提取的工具函数）
def pairwise_distances_no_broadcast(X, Y=None):
    if Y is None:
        Y = X
    return pairwise_distances(X, Y)
